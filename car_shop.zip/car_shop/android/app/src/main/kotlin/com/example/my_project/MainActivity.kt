package com.flutterflow.carshop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
